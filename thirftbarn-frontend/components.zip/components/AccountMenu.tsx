"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/utils/supabase/client";
import { signout } from "@/lib/auth-actions";

export default function AccountMenu() {
  const router = useRouter();
  const supabase = createClient();

  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.auth.getUser();
      setEmail(data.user?.email ?? null);
    };

    load();

    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setEmail(session?.user?.email ?? null);
    });

    return () => {
      sub.subscription.unsubscribe();
    };
  }, [supabase]);

  if (!email) {
    return (
      <button onClick={() => router.push("/login")}>
        Login
      </button>
    );
  }

  return (
    <div style={{ position: "relative" }}>
      <button onClick={() => setOpen((v) => !v)}>
        Account ▾
      </button>

      {open && (
        <div
          style={{
            position: "absolute",
            right: 0,
            top: "110%",
            background: "white",
            border: "1px solid #ddd",
            borderRadius: "8px",
            minWidth: "180px",
            zIndex: 1000,
          }}
        >
          <button
            className="menuItem"
            onClick={() => router.push("/account/orders")}
          >
            Order history
          </button>

          <button
            className="menuItem"
            onClick={() => router.push("/account/profile")}
          >
            Edit profile
          </button>

          <hr />

          <button
            className="menuItem"
            onClick={async () => {
              await signout();
              router.refresh();
            }}
          >
            Sign out
          </button>
        </div>
      )}
    </div>
  );
}
