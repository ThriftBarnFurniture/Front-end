import { redirect } from "next/navigation";
import { createClient } from "@/utils/supabase/server";

export default async function ProfilePage() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();

  if (!data.user) redirect("/login");

  return (
    <div style={{ marginTop: '300px'}}>
      <h1>Profile</h1>
      <p>Email: {data.user.email}</p>
      <p>User ID: {data.user.id}</p>
    </div>
  );
}
