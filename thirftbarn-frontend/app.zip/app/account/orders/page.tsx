import { redirect } from "next/navigation";
import { createClient } from "@/utils/supabase/server";

export default async function OrdersPage() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();

  if (!data.user) redirect("/login");

  const { data: orders } = await supabase
    .from("orders")
    .select("*")
    .eq("customer_email", data.user.email)
    .order("purchase_date", { ascending: false });

  return (
    <div style={{ marginTop: '300px'}}>
      <h1>Order history</h1>
      {!orders?.length && <p>No orders yet.</p>}
      {orders?.map((o) => (
        <div key={o.order_id}>
          #{o.order_number} — ${o.total}
        </div>
      ))}
    </div>
  );
}
