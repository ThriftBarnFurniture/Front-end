import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/utils/supabase/server";

export default async function AccountHome() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  if (!data.user) redirect("/login");

  return (
    <div style={{ marginTop: '400px', maxWidth: 720, margin: "0 auto", padding: 24 }}>
      <h1>My Account</h1>
      <ul style={{ marginTop: 12 }}>
        <li><Link href="/account/orders">Order history</Link></li>
        <li><Link href="/account/profile">Edit profile</Link></li>
      </ul>
    </div>
  );
}
