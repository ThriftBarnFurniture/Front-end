export default function Checkout() {
    return <div>Checkout Page</div>;
}